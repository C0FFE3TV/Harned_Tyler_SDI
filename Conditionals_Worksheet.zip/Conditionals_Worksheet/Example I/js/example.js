/*
Tyler Harned
Conditionals Worksheet
Full Sail - SDI #03
05/20/2015
Example I
 */

//Hot Enough?

// Is it hot enough to go to the beach?
var temp = prompt("What is the temperature? ");

//if the temperature is less than 75..
if(temp < 75){
//if its less than 75
console.log("We will go to the beach!");
}else{
//if it’s greater or equal to 75<br>
console.log("We will go to the movies!");
}
